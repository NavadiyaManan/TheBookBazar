import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './component/login/login.component';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './component/registration/registration.component';
import { AddAddressComponent } from './component/add-address/add-address.component';
import { GetOrdersComponent } from './component/get-orders/get-orders.component';
import { DashboardComponent } from './component/dashboard/dashboard.component';
import { GetAddressListComponent } from './component/get-address-list/get-address-list.component';
import { DraftOrdersComponent } from './component/draft-orders/draft-orders.component';
import { UpdateOrderStatusComponent } from './component/update-order-status/update-order-status.component';
import { UpdateOrderAddressComponent } from './component/update-order-address/update-order-address.component';
import { ProductComponent } from './component/product/product.component';
import { AuthGuardGuard } from './auth-guard.guard';

const routes: Routes = [
 { path: 'addAddress', component: AddAddressComponent ,canActivate:[AuthGuardGuard]},
 { path: 'getAddressList', component: GetAddressListComponent,canActivate:[AuthGuardGuard] },
 { path: 'getOrders', component: GetOrdersComponent,canActivate:[AuthGuardGuard]},
  { path: 'registration', component: RegistrationComponent },
  { path: 'login', component: LoginComponent },
  { path: '', component: LoginComponent },
  { path: 'draftOrder', component: DraftOrdersComponent,canActivate:[AuthGuardGuard] },
  { path: 'dashboard', component: DashboardComponent,canActivate:[AuthGuardGuard]},
  {path: 'UpdateOrderStatus/:orderId',component:UpdateOrderStatusComponent,canActivate:[AuthGuardGuard]},
  {path:'UpdateOrderAddress/:orderId',component:UpdateOrderAddressComponent,canActivate:[AuthGuardGuard]},
  {path:'Product',component:ProductComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
