import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-draft-orders',
  templateUrl: './draft-orders.component.html',
  styleUrls: ['./draft-orders.component.css']
})
export class DraftOrdersComponent implements OnInit {

  isLinear = false;
  Product: any;
  Address: any;

  constructor(private builder: FormBuilder, 
    private service: ServiceService,
    private router: Router, 
    private http: HttpClient, 
    private toastr: ToastrService) { }

  AddOrder: FormGroup = new FormGroup({
    Note: new FormControl(''),
    DisountAmount: new FormControl(''),
    CustomerName: new FormControl(''),
    CustomerContactNo: new FormControl(''),
  })

  orderItem: FormGroup = new FormGroup({
    ProductId: new FormControl(''),
    Quantity: new FormGroup(''),
    // orderItems: this.builder.array([]),
  })

  AddressIdForm: FormGroup = new FormGroup({
    AddressId: new FormControl('')
  })


  ngOnInit(): void {
    this.fetchDropdownValues()

    this.AddOrder = this.builder.group({
      Note: ['', [Validators.required]],
      DisountAmount: ['', [Validators.required, , Validators.pattern('^[0-9]+$')]],
      CustomerName: ['', [Validators.required]],
      CustomerEmail: ['', [Validators.required]],
      CustomerContactNo: ['', [Validators.required]],
    })

    this.orderItem = this.builder.group({
      ProductId: ['', [Validators.required]],
      Quantity: ['', [Validators.required]],
    })

    this.AddressIdForm = this.builder.group({

      AddressId: ['', Validators.required]
    })
  }

  get d(): { [key: string]: AbstractControl } {
    return this.AddOrder.controls;
  }

  get e(): { [key: string]: AbstractControl } {
    return this.orderItem.controls;
  }

  get f(): { [key: string]: AbstractControl } {
    return this.AddressIdForm.controls;
  }

  fetchDropdownValues() {
    this.http.get('http://localhost:7218/api/ProductForDropdown').subscribe(
      (response) => {
        this.Product = response
        console.log(this.Product)
      },
      (error) => {
        console.log('Error fetching dropdown values:', error);
      }
    );
    this.http.get('http://localhost:7218/api/GetAddressList').subscribe((res: any) => {
      this.Address = res
      console.log(this.Address)
    })
  }

  Order() {
    console.log(this.AddOrder.value)
  }
  OrderItem() {
    console.log(this.orderItem.value)
  }

  AddressIdItem() {
    console.log("Hello", this.AddressIdForm.value)
  }

  addProduct() {
    const productFormGroup = this.builder.group({
      ProductId: ['', Validators.required],
      Quantity: ['', Validators.required],
    });
    // this.orderItems.push(productFormGroup);
  }
  
  get orderItems(): FormArray {
    return this.orderItem.get('orderItems') as FormArray;
  }

  submitOrder() {
    if (this.AddOrder.invalid || this.orderItem.invalid || this.AddressIdForm.invalid) {
      // Handle form validation errors
      this.toastr.warning("Fill Proper details")
      return;
    }
    const orderData: any = {
      Note: this.AddOrder.value.Note,
      DisountAmount: this.AddOrder.value.DisountAmount,
      CustomerName: this.AddOrder.value.CustomerName,
      CustomerEmail: this.AddOrder.value.CustomerEmail,
      CustomerContactNo: this.AddOrder.value.CustomerContactNo,
      AddressId: this.AddressIdForm.value.AddressId,
      orderItems: [
        {
          ProductId: this.orderItem.value.ProductId,
          Quantity: this.orderItem.value.Quantity
        }
      ]
    };

    console.log(orderData)
    this.service.createDraftOrder(orderData).subscribe((res: any) => 
    {
        console.log('Draft order created successfully:', res);
        this.toastr.success("Draft order Added")
        this.router.navigate(['dashboard']);
    }, Error => this.toastr.error(Error.error)
    );
  }

}

