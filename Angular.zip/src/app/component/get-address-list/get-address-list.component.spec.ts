import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAddressListComponent } from './get-address-list.component';

describe('GetAddressListComponent', () => {
  let component: GetAddressListComponent;
  let fixture: ComponentFixture<GetAddressListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetAddressListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetAddressListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
