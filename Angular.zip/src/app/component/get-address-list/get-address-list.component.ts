import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-get-address-list',
  templateUrl: './get-address-list.component.html',
  styleUrls: ['./get-address-list.component.css']
})
export class GetAddressListComponent implements OnInit {
  list: any = [];
  dataSource: any;
  isLoading: boolean = false;
  displayedColumns: string[] = ['addressType', 'addressLine', 'country', 'state', 'city', 'zipCode', 'contactPerson', 'contactNo',];

  constructor(private service: ServiceService, private router: Router, private toastr: ToastrService) {
    this.getData();
  }

  ngOnInit(): void { this.isLoading = true; }

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  //get data 
  getData() {
    this.service.getData().subscribe((res: any) => {
      if (res != null)
        this.isLoading = false;
      this.list = res;
      this.dataSource = new MatTableDataSource(this.list);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, Error => this.toastr.error(Error.error));
  }

}
