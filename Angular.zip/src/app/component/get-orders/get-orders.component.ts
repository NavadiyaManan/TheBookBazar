import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-get-orders',
  templateUrl: './get-orders.component.html',
  styleUrls: ['./get-orders.component.css']
})
export class GetOrdersComponent implements OnInit {

  list :any=[];
  dataSource: any;
  isLoading: boolean = false;
  customerName: string = '';
  selectedStatus: string = '';
  displayedColumns: string[] = ['orderId','description', 'customerEmail', 'customerName','status','totalItems', 'totalAmount','shippingAddress','actions'];
  filterForm!: FormGroup;

 
  getFilteredOrders(): void {
    this.isLoading = true;
    let filteredOrders = this.list;
  
    if (this.customerName !== '') {
      const searchTextLower = this.customerName.toLowerCase();
      console.log(searchTextLower)
      filteredOrders = filteredOrders.filter((order: any) =>
        order.customerName.toLowerCase().includes(searchTextLower) ||
        order.customerEmail.toLowerCase().includes(searchTextLower)
      );
    }
  
    if (this.selectedStatus !== '') {
      console.log(this.selectedStatus)
      filteredOrders = filteredOrders.filter((order: any) =>
        order.status.toLowerCase() === this.selectedStatus.toLowerCase()
      );
    }
    this.dataSource.data = filteredOrders
   
  }
  constructor(private service: ServiceService,
    private router: Router,
    private dialog: MatDialog,
    private toastr: ToastrService
    ) {
    this.getData();
  }

  ngOnInit(): void {
 
      this.filterForm = new FormGroup({
        startDate: new FormControl(),
        endDate: new FormControl(),
        status: new FormControl(),
        customerSearch: new FormControl()
      }
    ); 
  }

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  //get data 
  getData() {
    this.service.GetOrderData().subscribe((res: any) => {
      this.list = res;
        this.dataSource = new MatTableDataSource(this.list);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    },Error=>this.toastr.error(Error.error));
  }



  updateStatus(orderId: string) {
   this.router.navigateByUrl('UpdateOrderStatus')
  }

  getStatusLabel(status: number): string {
    switch (status) {
      case 0:
        return 'Open';
      case 1:
        return 'Draft';
      case 2:
        return 'Shipped';
      case 3:
        return 'Paid';
      default:
        return '';
    }
  }
  
}






