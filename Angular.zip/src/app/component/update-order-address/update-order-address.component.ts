import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Toast, ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-update-order-address',
  templateUrl: './update-order-address.component.html',
  styleUrls: ['./update-order-address.component.css']
})
export class UpdateOrderAddressComponent  implements OnInit {
  address : any;
  id: any;
  selectedaddress: any;
  constructor(private service: ServiceService,private router:ActivatedRoute, private route:Router,private toastr:ToastrService) {}
    ngOnInit(): void {
      this.router.paramMap.subscribe((params:any) => {
        this.id = params.get('orderId');
      });
      this.getAddresses();
    }
    
    getAddresses(): void {
      this.service.getData().subscribe((res:any) => {
        this.address = res;
        console.log(this.address)
      });
    }
  
    updateAddress() {
      console.log(this.selectedaddress)
  
      var adderss = {
        AddressId: this.selectedaddress
      }
  
      console.log(adderss)
        this.service.updateAddress(this.id,adderss).subscribe((res:any) =>
         {
          this.route.navigate(['/getOrders'])
            console.log(res)
            this.toastr.success("Update Address SuccessFully");
          
        },Error => this.toastr.error(Error.error));
        
  }
  }
  