import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ErrorServiceService {

  constructor(
    // private toastr: ToastrService
    ) { }

  handleError(error: HttpErrorResponse): Observable<never> {
    let error_msg: any = ''
    if (error.status == 404) {
      error_msg = error.message
    }
    else if (error.error.status == 400) {
      error_msg = error.error.message
    }
    else {
      error_msg = error.error.message
    }
    error_msg = error.error.message

    // this.toastr.error(error_msg, 'Error', {
    //   closeButton: true,
    //   timeOut: 3000,
    //   positionClass: 'toast-top-right'
    // })



    return throwError(error_msg)
  }

}
