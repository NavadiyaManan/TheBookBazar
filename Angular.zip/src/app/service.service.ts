import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ErrorServiceService } from './error-service.service';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {


  constructor(private http: HttpClient, private errorservice: ErrorServiceService,private router:Router){}

  createDraftOrder(orderData: { orderDetails: any; orderItems: any; addressId: any; }) {
    return this.http.post(`http://localhost:7218/api/Draftorder`,orderData)
    // throw new Error('Method not implemented.');
  } 
  fetchProducts( ) {
    return this.http.get<any[]>(`http://localhost:7218/api/ProductForDropdown`)
  }
  Login(value: any) {
    return this.http.post(`https://localhost:7127/api/UserAuthentication/login`,value)
  }
  Register(value: any) {
    return this.http.post(`https://localhost:7127/api/UserAuthentication/AddUser`,value)
  }
  isLoggedIn() {
    return localStorage.getItem('token') != null
  }
  AddOrder(data:any) {
    console.log(data)
     this.http.post(`http://localhost:7218/api/AddAddress`, data)
  }
  AddAddress(data:any){
    return this.http.post(`http://localhost:7218/api/AddAddress`, data)
    
  }


  header = new HttpHeaders({
    'accept': 'application/json',
    'Authorization': 'Bearer ' + localStorage.getItem('token')
  })
    
  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['login']);
  }
  uploadImage(selectedImage: File) {
    throw new Error('Method not implemented.');
  }
  getData() {
    return this.http.get(`http://localhost:7218/api/GetAddressList`)
  }
  GetOrderData(){
    return this.http.get(`http://localhost:7218/api/GetOrder`)
  }
  updatestatus(data:any) {
    return this.http.put(`http://localhost:7218/api/Order/Status`,data)
  }
  updateAddress(id:any,data:any) {
    
    return this.http.put(`http://localhost:7218/api/updateOrderAddress/${id}`, data);
   }
}
