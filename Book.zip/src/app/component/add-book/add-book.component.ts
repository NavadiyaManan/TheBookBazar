import { Component } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.scss'],
})
export class AddBookComponent {
  selectedValue!: string;

  books: string[] = [
    'Fiction',
    'Nonfiction',
    'Tragedy',
    'Science Fiction',
    'Fantasy',
    'Fairytale',
    'Adventure',
    'Crime & Mystery',
    'Historical Fiction',
    // {value: 'Fiction', viewValue: 'Fiction'},
    // {value: 'Nonfiction', viewValue: 'Nonfiction'},
    // {value: 'Tragedy', viewValue: 'Tragedy'},
    // {value: 'Science Fiction', viewValue: 'Science Fiction'},
    // {value: 'Fantasy', viewValue: 'Fantasy'},
    // {value: 'Fairytale', viewValue: 'Fairytale'},
    // {value: 'Adventure', viewValue: 'Adventure'},
    // {value: 'Crime & Mystery', viewValue: 'Crime & Mystery'},
    // {value: 'Historical Fiction', viewValue: 'Historical Fiction'}
  ];

  title = 'Add Book';
  submitted = false;
  isLogin = false;
  price: string = '';
  password: string = '';
  IsSignIn = false;
  addUserForm!: FormGroup;

  selectedImage: any = null;

  title1!: string;
  author!: string;
  isbn!: string;
  condition!: string;
  id!: string;
  img!: String;
  buttonName!: string;
  file: any;
  filePath: any;
  path!: string;
  category = new FormControl('');
  constructor(private builder: FormBuilder) {}

  ngOnInit(): void {
    this.addUserForm = this.builder.group({
      id: [this.id, []],
      title1: [this.title1, [Validators.required]],
      author: [this.author, [Validators.required]],
      isbn: [this.isbn, [Validators.required]],
      price: [this.price, [Validators.required]],
      condition: [this.condition, [Validators.required]],
      img: [this.img, [Validators.required]],
      category: ['', [Validators.required]],
    });
  }

  uploadImage(event: any) {
    this.file = event.target.files[0];
    this.filePath = `images/${this.file.name}`;

    if (event.target.files && event.target.files[0]) {
      this.file = event.target.files[0];
      // const reader = new FileReader();
      // this.filePath= reader.readAsDataURL(this.file.name);
      this.filePath = this.file.name;
      this.selectedImage = event.target.files[0];
      // this._storage.upload(this.filePath, this.file.name)
      // this.addUserForm.value.file = this.file
      // this.addUserForm.value.filePath = this.filePath
    }
  }

  addBook() {
    // this.isSubmitted = true;
    if (this.addUserForm.valid) {
      // var filePath = `${this.addUserForm.value.category}/${this.filePath}_${new Date().getTime()}`;
    }
  }
}
