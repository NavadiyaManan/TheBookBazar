import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  
 hide = true

 constructor(private builder:FormBuilder) {}

    loginform : FormGroup = new FormGroup ({
      email : new FormControl(''),
      password: new FormControl(''),
      firstname: new FormControl('')
    })

    ngOnInit(): void {
     this.loginform = this.builder.group({
      email: ['', [Validators.required,Validators.email]],
      password: ['', [Validators.required,Validators.minLength(8)]],
     })
    }
  

    get d(): { [key: string]: AbstractControl } {
      return this.loginform.controls;
    }
    userlogin(){
        
    }

}
