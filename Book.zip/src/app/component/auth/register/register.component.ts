import { Component } from '@angular/core';
import { FormGroup, FormControl, AbstractControl, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
  registerform: FormGroup = new FormGroup({
    fname: new FormControl(''),
    lname: new FormControl(''),
    mnum: new FormControl(''),
    age: new FormControl(''),
    email: new FormControl(''),
    password: new FormControl(''),
  });

  birthdate!: Date
  title = "Registration From"
  submitted = false;
  isLogin = false;
  email: string = '';
  password: string = '';
  IsSignIn = false

constructor(private builder: FormBuilder) {}
  ngOnInit(): void {
    this.registerform = this.builder.group(
      {
        fname: ['', [Validators.required]],
        mnum: ['', [Validators.required, Validators.maxLength(10), Validators.minLength(10)]],
        lname: ['', [Validators.required]],
        age: ['', [Validators.required]],
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(8)]],
      },
    );
  }
  get f(): { [key: string]: AbstractControl } {
    return this.registerform.controls;
  }

  register(){}

}
