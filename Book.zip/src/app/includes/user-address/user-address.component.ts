import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user-address',
  templateUrl: './user-address.component.html',
  styleUrls: ['./user-address.component.scss']
})
export class UserAddressComponent {
  category!:string;
  hide = true
  selectedValue!: string;
  books = [
    {value: 'Fiction', viewValue: 'Fiction'},
    {value: 'Nonfiction', viewValue: 'Nonfiction'},
    {value: 'Tragedy', viewValue: 'Tragedy'},
    {value: 'Science Fiction', viewValue: 'Science Fiction'},
    {value: 'Fantasy', viewValue: 'Fantasy'},
    {value: 'Fairytale', viewValue: 'Fairytale'},
    {value: 'Adventure', viewValue: 'Adventure'},
    {value: 'Crime & Mystery', viewValue: 'Crime & Mystery'},
    {value: 'Historical Fiction', viewValue: 'Historical Fiction'}

  ];
  firstFormGroup = this.builder.group({
    firstCtrl: ['', Validators.required],
  });
  secondFormGroup = this.builder.group({
    secondCtrl: ['', Validators.required],
  });
  isLinear = false;

  constructor(private builder:FormBuilder) {}
 
     loginform : FormGroup = new FormGroup ({
       email : new FormControl(''),
       password: new FormControl(''),
       firstname: new FormControl(''),
       category:new FormControl('')
     })
 
     ngOnInit(): void {
      this.loginform = this.builder.group({
        firstname:['',[Validators.required]],
        category:[this.category, [Validators.required]],
       email: ['', [Validators.required,Validators.email]],
       password: ['', [Validators.required,Validators.minLength(8)]],
      })
     }
   
 
     get d(): { [key: string]: AbstractControl } {
       return this.loginform.controls;
     }
     userlogin(){
         
     }
}
