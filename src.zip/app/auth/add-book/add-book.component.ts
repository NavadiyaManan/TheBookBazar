import { Component, Inject, OnInit } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { finalize } from 'rxjs';
import { AuthService } from 'src/app/shared/auth.service';
import { BookServiceService } from 'src/app/shared/book.service.service';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent implements OnInit {

  selectedValue!: string;

  books = [
    {value: 'Fiction', viewValue: 'Fiction'},
    {value: 'Nonfiction', viewValue: 'Nonfiction'},
    {value: 'Tragedy', viewValue: 'Tragedy'},
    {value: 'Science Fiction', viewValue: 'Science Fiction'},
    {value: 'Fantasy', viewValue: 'Fantasy'},
    {value: 'Fairytale', viewValue: 'Fairytale'},
    {value: 'Adventure', viewValue: 'Adventure'},
    {value: 'Crime & Mystery', viewValue: 'Crime & Mystery'},
    {value: 'Historical Fiction', viewValue: 'Historical Fiction'}

  ];

  title = "Add Book"
  submitted = false;
  isLogin = false;
  price: string = '';
  password: string = '';
  IsSignIn = false
  addUserForm!: FormGroup;


  selectedImage: any = null;


  title1 !: string;
  author !: string;
  isbn !: string;
  condition !: string;
  id !: string;
  img!:String;
  buttonName !: string;
  file:any;
  filePath:any;;
  path!: string;
  category!:string;
  constructor(
    private auth: AuthService,
    private router: Router,
    private builder: FormBuilder,
    // private book_service:BookServiceService,
    private toastr: ToastrService,
    private service:BookServiceService,
    private _storage:AngularFireStorage,
  ){  }

  ngOnInit(): void {

    this.addUserForm = this.builder.group({
      id: [this.id, []],
      title1: [this.title1, [Validators.required]],
      author: [this.author, [Validators.required]],
      isbn: [this.isbn, [Validators.required]],
      price: [this.price, [Validators.required]],
      condition: [this.condition, [Validators.required]],
      img: [this.img, [Validators.required]],
      category:[this.category, [Validators.required]]

    })
  }


 
  uploadImage(event: any) {
     this.file = event.target.files[0];
     this.filePath = `images/${this.file.name}`;

    //  this.addUserForm.value.file = this.file 
    //  this.addUserForm.value.filePath = this.filePath 
    if (event.target.files && event.target.files[0]) {
      this.file = event.target.files[0];
      // const reader = new FileReader();
      // this.filePath= reader.readAsDataURL(this.file.name);
      this.filePath=this.file.name
      this.selectedImage = event.target.files[0];
      // this._storage.upload(this.filePath, this.file.name)
      // this.addUserForm.value.file = this.file 
      // this.addUserForm.value.filePath = this.filePath 
    }
  }

  addBook(){
    // this.isSubmitted = true;
    if (this.addUserForm.valid) {
      // var filePath = `${this.addUserForm.value.category}/${this.filePath}_${new Date().getTime()}`;
      const fileRef = this._storage.ref(this.filePath);
      this._storage.upload(this.filePath, this.file).snapshotChanges().pipe(
        finalize(() => {
          fileRef.getDownloadURL().subscribe((url) => {
            this.addUserForm.value.img = url;
            this.service.addBook(this.addUserForm.value)
            this.router.navigate(['dashboard'])
            console.log("data added successfully")
          })
        })
      ).subscribe();
    }
  }



}

