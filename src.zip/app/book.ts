// interface 
export interface book{
    id:string,
    title1:string,
    lname:string,
    email:string,
    age:string,
    mnum:string,
    file:string,
    file_path:string

}