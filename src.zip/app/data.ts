// interface 
export interface data{
    id:string,
    fname:string,
    lname:string,
    email:string,
    age:string,
    mnum:string

}