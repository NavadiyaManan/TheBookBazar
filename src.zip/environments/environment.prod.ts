export const environment = {
  firebase: {
    projectId: 'thebookbazar2',
    appId: '1:960033997850:web:e3e46b21f0afca2e837da3',
    storageBucket: 'thebookbazar2.appspot.com',
    apiKey: 'AIzaSyDrkB2mFCU2P8UJWu4pH_-WJY92tteGYzI',
    authDomain: 'thebookbazar2.firebaseapp.com',
    messagingSenderId: '960033997850',
    measurementId: 'G-NZYV96HR91',
  },
  production: true
};
