import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {AngularFireAuth} from '@angular/fire/compat/auth'
import { async } from '@firebase/util';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  result: any;
  res: any;
  constructor(private fireAuth : AngularFireAuth, private router : Router) { 
    

  }
  login(email : string, password : string) {
    this.fireAuth.signInWithEmailAndPassword(email,password).then( res => {
    this.result=res;
    console.log("login",res.user)
       if(res.user?.emailVerified == true) {
        if(this.res.isactive)
        {
         
          this.router.navigate(['/dashboard']);
          localStorage.setItem('username',this.res.user)
          sessionStorage.setItem('username',this.res.email);
        }
      }
      else {
      this.router.navigate(['/varify-email']);
      }


    }, err => {
        alert(err.message);
        this.router.navigate(['/login']);
    })
  }
  isloggedin(){
    return sessionStorage.getItem('username')!=null;
  }

   register(email : string, password : string) {{
     this.fireAuth.createUserWithEmailAndPassword(email, password).then( res => {
      
     this.sendEmailForVarification(res.user);
     this.router.navigate(['/varification']);
     }, err => {
       alert(err.message);
       this.router.navigate(['/register']);
     })  
   }
   }
  // sign out
  logout() {
    this.fireAuth.signOut().then( () => {
      localStorage.removeItem('token');
      this.router.navigate(['/login']);
    }, err => {
      alert(err.message);
    })
  }

  // forgot password
  forgotPassword(email : string) {
      this.fireAuth.sendPasswordResetEmail(email).then(() => {
        this.router.navigate(['/varify-email']);
      }, err => {
        alert('Something went wrong');
      })
  }

  // email varification
  sendEmailForVarification(user : any) {
    console.log(user);
    user.sendEmailVerification().then((res : any) => {
      this.router.navigate(['/varify-email']);
    }, (err : any) => {
      alert('Something went wrong. Not able to send mail to your email.')
    })
  }

  isLogin(){
    return localStorage.getItem('user')!=null
  }
}
